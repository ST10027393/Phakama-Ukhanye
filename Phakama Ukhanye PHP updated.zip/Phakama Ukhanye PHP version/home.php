<?php 

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phakama Ukhanye - Home</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="pagewrapper">
		<?php include 'header.php'; ?>
		<div class="container">
            <section id="home" class="home-section">
                <div class="home-style">
                    <h1><font color="green" font-weight="bold">Phakama Ukhanye</font> 
                        Welcomes You</h1>
                    <h2>Arise and Shine</h2>
                    <br>
                    <br>
                    <p>Phakama Ukhanye is a non-profit organization dedicated to empowering communities 
                    through education, healthcare, and economic development initiatives.</p>
                    <br>
                    <br>
                    <h3>Our Mission</h3>
                    <p>Our mission is to create a sustainable future for communities in need by providing access to education, 
                            healthcare, and economic opportunities.</p>
                    <br>
                    <br>
                    <a href="about.php" target="_blank"><button class="btn">Find Out More</button></a>
                    <br>
                    <br>
                </div>
            </section>
            <section id="projects" class="projects-section">
                <div class="project-style">
                    <center><h2>Our Projects</h2></center>
                    <br>
                    <div class="row">
                        <div class="column">
                            <ul>
                                <li>Reading Club</li>
                                <li>Home Based Care</li>                                
                                <li>Orphans Care</li>                                                                
                                <li>Food Parcel Distribution</li>
                            </ul>
                        </div>
                        <div class="column">
                            <ul>                                    
                                <li>Disaster Management</li>                                        
                                <li>Hospital Visits</li>
                                <li>Medicine Collection</li>
                                <li>Zulu Bible Study</li>
                            </ul>
                        </div>
                    </div> 
                </div>
            </section>
            <section id="donate" class="donate-section">
                <div class="donate-style">
                    <center><h2>Get Involved</h2></center>
                    <br>
                    <center><h3>Be a part of this wonderful story, help us by</h3></center>
                    <a href="donate.php"><img src="gallery\Donate page\DonateImg.jpg" alt="donation link"></a>
                    <a href="donate.php"><img src="gallery\Donate page\FundraiseImg.png" alt="fundraising link"></a>
                    <center><a href="donate.php"><img src="gallery\Donate page\VolunteerImg.png" alt="volunteering link"></a></center>
                </div>
            </section>
            <section id="contact" class="contact-section">
                <div class="contact-style">
                    <center><h2>Get In Touch</h2></center>
                        <form>
                          <div class="input-box">
                            <label for="name">Name:</label>
                            <input type="text" id="name" name="name" placeholder="John Doe" required>
                      
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" placeholder="example@example.com" 
                            required>
                          </div>
                      
                          <label for="message">Message:</label>
                          <textarea id="message" name="message" rows="5" placeholder="Write you're message here" required></textarea>
                      
                          <div>
                            <button type="submit" class="btn">Submit</button>
                          </div>
                        </form> 
                    <center><h2>Set An Appoinetment</h2></center>
                    <center>
                    <a href="contact.php" target="_blank"><button class="btn">Click Here</button></a>
                                                                          
                    </center>
                </div>
            </section>
        </div>
	
		<?php include 'footer.php'; ?>
	</div>
	<script src="script.js"></script>
</body>
</html>
