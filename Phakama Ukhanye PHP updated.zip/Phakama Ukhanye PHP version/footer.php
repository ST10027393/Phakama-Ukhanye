<footer>
    <div>
        <div class="footer">
            <small>
                <p>&copy; 2023 Phakama Ukhanye - Design by Genius Muzama</p>
            </small>
            <strong>
                <a href="home.php">Home</a>&nbsp;&nbsp;
                <a href="about.php">About Us</a>&nbsp;&nbsp;
                <a href="projects.php">Projects</a>&nbsp;&nbsp;
                <a href="donate.php">Donate</a>&nbsp;&nbsp;
                <a href="contact.php">Get In Touch</a>
            </strong>
        </div>
    </div>
</footer>