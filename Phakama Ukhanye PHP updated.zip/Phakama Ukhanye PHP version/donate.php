<?php 

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phakama Ukhanye - Donate</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="pagewrapper">
		<?php include 'header.php'; ?>
        <div class="container">
        <section class="donate">
            <table border="4" align="center">
                <tr>
                    <th colspan="8"> <center>Donate with your prefered bank</center> </th>
                </tr>
                
                <tr>
                   
                    <td>
                        <a href="https://www.fnb.co.za/" target="_blank">
                            <img src="gallery\Donate page\bank1.webp" height="200" width="200">
                        </a>
                    </td> &nbsp;
                    <td>
                        <a href="https://www.absa.africa/" target="_blank">
                            <img src="gallery\Donate page\bank2.webp" height="200" width="200">
                        </a>
                    </td> &nbsp;
                    <td>
                        <a href="https://www.standardbank.co.za/southafrica/personal/home" target="_blank">
                            <img src="gallery\Donate page\bank3.png" height="200" width="200">
                        </a>
                    </td> &nbsp;
                    <td>
                        <a href="https://www.capitecbank.co.za/" target="_blank">
                            <img src="gallery\Donate page\bank4.png" height="200" width="200">
                        </a>
                    </td> 
                </tr>
            </table>
            <br>
            <br>
        </section>
    </div>
	
	
		<?php include 'footer.php'; ?>
	</div>
    <script src="script.js"></script>
</body>
</html>
