<?php
$title = "Contact Us";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    $to = "gtmuzama@gmail.com";
    $subject = "New message from website";
    $body = "Name: $name\nEmail: $email\nMessage: $message";

    if (mail($to, $subject, $body)) {
        echo "Email sent successfully";
    } else {
        echo "Error: Unable to send email";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phakama Ukhanye - <?php echo $title; ?></title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="pagewrapper">
		<?php include 'header.php'; ?>
        <div class="container">
        <section id="contact" class="contact-section">
                <div class="contact-style">
                    <center><h2>Get In Touch</h2></center>
                        <form>
                          <div class="input-box">
                            <label for="name">Name:</label>
                            <input type="text" id="name" name="name" placeholder="John Doe" required>
                      
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" placeholder="example@example.com" 
                            required>
                          </div>
                      
                          <label for="message">Message:</label>
                          <textarea id="message" name="message" rows="5" placeholder="Write you're message here" required></textarea>
                      
                          <div>
                            <button type="submit" class="btn">Submit</button>
                          </div>
                        </form> 
            </section>
            <center><p>
                <h1> <font color="green" size="15" align="center"> Contact Details</font> </h1>
                <h4> Name of Contact Person : </h4>  Phakama Ukhanye Supporter Care
                <br>
               <h4> Address :</h4>  16 Jameson Terrace, Kloof, Durban, 3610
            
                <br>
                <h4> Telephone No: </h4> (012) 345-6789
                <br> 
                <h4> Email : </h4> connect@phakamaukhanye.co.za
            </p></center>
            <center> <iframe width="30%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3462.360115965413!2d30.8497245157161!3d-29.796138926733324!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1ef6fdd4ee6b5383%3A0x286d83dd368196c9!2s16%20Jameson%20Terrace%2C%20Kloof%2C%203640%2C%20Zuid-Afrika!5e0!3m2!1snl!2snl!4v1680090882016!5m2!1snl!2snl">
                     </iframe> 
            </center>
            <br> 
            <br> 
        </div>
	
		<?php include 'footer.php'; ?>
	</div>
    <script src="script.js"></script>
</body>
</html>
