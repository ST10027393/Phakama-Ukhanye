<header class="header">
            <div class="logo header-div">
                <a href="home.html"><img src="gallery\logos\logo 14.png"  alt="logo of NGO"></a>
            </div>
            <div class="slogan header-div">
            <center><font>Phakama Ukhanye</font></center>
            </div>
            <div class="header-div">
                <nav class="navbar">
                    <div>
                        <a href="home.php"> Home</a>
                        <a href="about.php"> About Us</a>
                        <a href="projects.php"> Projects</a>
                        <a href="donate.php"> Donate</a>
                        <a href="contact.php"> Get in Touch</a>
                    </div>
                </nav>
            </div>
        </header>