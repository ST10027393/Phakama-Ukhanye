<?php 

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phakama Ukhanye - About Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="pagewrapper">
		<?php include 'header.php'; ?>
        <div class="container" style="padding-top: 60px;">
            <center>
                <h2>Our History</h2>
                <p>The name Phakam u'Khanye means "arise and shine" and is inspired by Isaiah 60:1. 
                    We are a ministry that is part of YWAM Durban and based in a township called Burlington. 
                    Central to who we are and how we operate is empowerment and community ownership. 
                    Our desire is to grow in faith and love in relationship with one another and to promote 
                    and health and life in our community. We do this by meeting regularly for Bible study 
                    and support one another and by reaching out to people in need through home visits and 
                    food parcels. 
                    <br>
                    <br>
                    Igama u Phakama ukhanye amazwi esiwathola kuIsalah 60 v. 1. Inhlangano u Phakama ukhanye 
                    isebenzisana leYWAM. U Phakama ukhanye isebenzisana lomphakathi wase Burlington ngokuxumana, 
                    lokukhuthaza, langokuthuthukisa izidingo ngokomphakathi ngokubambisana. Isifiso sethu 
                    yikubambisana ngethemba lothando. Yikuba siqakambise ithemba lothando ngokwempilo nenhlalo 
                    emphakathini wethu. Sikwenza lokhu ngokuhlangana sifundisana ingcwadi engcwele (Bible) 
                    ngokwesekana sivakatshela amakhaya ahlwempu. Sinikela ngezidingo nqandi. 
                </p>
            </center>
        </div>
	
		<?php include 'footer.php'; ?>
	</div>
    <script src="script.js"></script>
</body>
</html>
