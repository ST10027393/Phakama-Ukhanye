<?php 

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phakama Ukhanye - Projects</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        .pagewrapper {
            overflow-y: scroll;
        }

        .container {
            border-width:3px; 
            border-style: solid; 
            background-color: #fdfd77; 
            border-color: rgb(4, 21, 3); 
            padding: 1em;
        }

        li {
            list-style: none;
            margin: 0;
            padding: 5px;
            border: none;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
        }
    </style>
</head>
<body>
	<div class="pagewrapper">
		<?php include 'header.php'; ?>
        <div class="container" style="padding: 1em;">
            <div>
                <p>
                    <center><h2>Our Projects</h2></center>
                    <ul>
                        <li>Reading Club</li>
                        <br>
                        <li>Home Based Care</li>
                        <br>
                        <li>Orphans Care</li>
                        <br>    
                        <li>Food Parcel Distribution</li>
                        <br>
                        <li>Disaster Management</li>
                        <br>    
                        <li>Hospital Visits</li>
                        <br>
                        <li>Medicine Collection</li>                        
                        <br>
                        <li>Zulu Bible Study</li>
                        <br>
                    </ul>
                </p>
            </div>
	
	
		<?php include 'footer.php'; ?>
	</div>
    <script src="script.js"></script>
</body>
</html>
